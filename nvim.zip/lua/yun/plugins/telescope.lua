return {
  "nvim-telescope/telescope.nvim",
  dependencies = {
    "nvim-lua/plenary.nvim",
    "nvim-telescope/telescope-file-browser.nvim"
  },
  config = function()
    local builtin = require("telescope.builtin")

    vim.keymap.set("n", "sf", builtin.find_files, {})
    vim.keymap.set("n", "sg", builtin.git_files, {})
    vim.keymap.set("n", "<space>e", ":Telescope file_browser<CR>", {})

    require("telescope").setup({
      defaults = {
        mappings = {
          n = {
            [";g"] = function()
              builtin.live_grep({})
            end,
          },
        },
      },
      extensions = {
	      file_browser = {
		      theme = "ivy",
		      hijack_netrw = true,
	      }
      }
    })
  end,
}
